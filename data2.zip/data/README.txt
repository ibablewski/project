project
=======

distributed algorithms for ec527

Author's: Ian & Kate

